import { r as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as ShieldCheck, c as KeyRound, d as Car, f as Building2, i as Sparkles, l as HandCoins, n as Truck, o as Phone, r as TrendingUp, s as MessageCircle, t as UserRound, u as CircleCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-R64XwqYb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var grupo_invest_logo_default = "/assets/grupo-invest-logo-BYs1KUjT.jpg";
var gestores_default = "/assets/gestores-DZrSSdDt.png";
var hero_imovel_default = "/assets/hero-imovel-BXph8lun.jpeg";
var CATEGORIAS = [
	{
		id: "imovel",
		nome: "Imóvel",
		icon: Building2,
		min: 1e5,
		max: 15e5,
		step: 1e4,
		prazos: [
			120,
			150,
			180,
			200,
			240
		],
		taxaAdm: .19,
		fundoReserva: .02
	},
	{
		id: "auto",
		nome: "Automóvel",
		icon: Car,
		min: 3e4,
		max: 3e5,
		step: 5e3,
		prazos: [
			48,
			60,
			72,
			80,
			100
		],
		taxaAdm: .17,
		fundoReserva: .02
	},
	{
		id: "pesados",
		nome: "Pesados",
		icon: Truck,
		min: 8e4,
		max: 8e5,
		step: 1e4,
		prazos: [
			60,
			80,
			100,
			120,
			150
		],
		taxaAdm: .18,
		fundoReserva: .02
	}
];
var brl = (v) => v.toLocaleString("pt-BR", {
	style: "currency",
	currency: "BRL",
	maximumFractionDigits: 0
});
function SimuladorConsorcio({ whatsapp }) {
	const [catId, setCatId] = (0, import_react.useState)(CATEGORIAS[0].id);
	const categoria = CATEGORIAS.find((c) => c.id === catId);
	const [credito, setCredito] = (0, import_react.useState)(35e4);
	const [prazo, setPrazo] = (0, import_react.useState)(200);
	const valorCredito = Math.min(Math.max(credito, categoria.min), categoria.max);
	const prazoAtual = categoria.prazos.includes(prazo) ? prazo : categoria.prazos[categoria.prazos.length - 1];
	const { parcela, total, custo } = (0, import_react.useMemo)(() => {
		const total = valorCredito * (1 + categoria.taxaAdm + categoria.fundoReserva);
		return {
			total,
			parcela: total / prazoAtual,
			custo: total - valorCredito
		};
	}, [
		valorCredito,
		prazoAtual,
		categoria
	]);
	const trocarCategoria = (c) => {
		setCatId(c.id);
		setCredito(Math.round((c.min + c.max) / 2 / c.step) * c.step);
		setPrazo(c.prazos[c.prazos.length - 1]);
	};
	const mensagem = `${whatsapp}?text=${encodeURIComponent(`Olá! Simulei um consórcio de ${categoria.nome.toLowerCase()} de ${brl(valorCredito)} em ${prazoAtual} meses (parcela aprox. ${brl(parcela)}). Quero receber a proposta completa.`)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 rounded-[2rem] border border-border bg-card p-6 shadow-card sm:p-10 lg:grid-cols-[1.15fr_0.85fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold uppercase tracking-[0.22em] text-sky",
				children: "Simulador"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 text-2xl font-bold tracking-tight text-navy sm:text-3xl",
				children: "Monte seu plano em segundos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-7 grid grid-cols-3 gap-2 rounded-2xl bg-sky-soft p-1.5",
				children: CATEGORIAS.map((c) => {
					const Icon = c.icon;
					const ativo = c.id === catId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => trocarCategoria(c),
						className: ativo ? "flex items-center justify-center gap-2 rounded-xl bg-navy px-3 py-2.5 text-xs font-bold text-primary-foreground sm:text-sm" : "flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-xs font-semibold text-navy/70 transition-colors hover:bg-background/70 sm:text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }), c.nome]
					}, c.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "credito",
							className: "text-sm font-semibold text-navy",
							children: "Valor do crédito"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl font-extrabold text-navy",
							children: brl(valorCredito)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "credito",
						type: "range",
						min: categoria.min,
						max: categoria.max,
						step: categoria.step,
						value: valorCredito,
						onChange: (e) => setCredito(Number(e.target.value)),
						className: "mt-4 h-2 w-full cursor-pointer appearance-none rounded-full bg-sky-soft accent-sky"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-between text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: brl(categoria.min) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: brl(categoria.max) })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-navy",
					children: "Prazo (meses)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: categoria.prazos.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPrazo(p),
						className: p === prazoAtual ? "rounded-full bg-navy px-5 py-2 text-sm font-bold text-primary-foreground" : "rounded-full border border-border px-5 py-2 text-sm font-medium text-navy transition-colors hover:border-sky hover:text-sky",
						children: p
					}, p))
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-between rounded-[1.5rem] bg-brand-gradient p-7 shadow-soft",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.2em] text-sky",
					children: "Parcela estimada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-4xl font-extrabold leading-none text-primary-foreground",
					children: brl(parcela)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-primary-foreground/70",
					children: "por mês, sem juros"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-7 space-y-3 border-t border-primary-foreground/15 pt-5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-primary-foreground/70",
								children: "Crédito contratado"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold text-primary-foreground",
								children: brl(valorCredito)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-primary-foreground/70",
								children: "Prazo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "font-semibold text-primary-foreground",
								children: [prazoAtual, " meses"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-primary-foreground/70",
								children: "Taxa de administração"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "font-semibold text-primary-foreground",
								children: [(categoria.taxaAdm * 100).toFixed(0), "%"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-primary-foreground/70",
								children: "Custo total do plano"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold text-sky",
								children: brl(custo)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-primary-foreground/70",
								children: "Total a pagar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold text-primary-foreground",
								children: brl(total)
							})]
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: mensagem,
					className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-sky px-6 py-3.5 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.02]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), "Receber proposta completa"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-[11px] leading-relaxed text-primary-foreground/60",
					children: "Valores simulados para referência. A proposta oficial é enviada pela nossa equipe."
				})]
			})]
		})]
	});
}
var WHATSAPP = "https://wa.me/5500000000000";
var beneficios = [
	{
		icon: HandCoins,
		titulo: "Sem juros",
		texto: "Você paga apenas taxa de administração — nada de juros bancários corroendo seu patrimônio."
	},
	{
		icon: TrendingUp,
		titulo: "Parcela que cabe",
		texto: "Planos flexíveis a partir de valores acessíveis, ajustados ao seu orçamento real."
	},
	{
		icon: KeyRound,
		titulo: "Poder de compra à vista",
		texto: "Na contemplação você negocia como comprador à vista e conquista os melhores descontos."
	},
	{
		icon: ShieldCheck,
		titulo: "Segurança total",
		texto: "Administradoras autorizadas e fiscalizadas pelo Banco Central do Brasil."
	}
];
var passos = [
	{
		n: "01",
		t: "Diagnóstico",
		d: "Entendemos seu objetivo, prazo e capacidade de investimento."
	},
	{
		n: "02",
		t: "Plano ideal",
		d: "Selecionamos a carta de crédito e o grupo certo para o seu perfil."
	},
	{
		n: "03",
		t: "Estratégia de lance",
		d: "Montamos o caminho mais rápido até a contemplação."
	},
	{
		n: "04",
		t: "Chaves na mão",
		d: "Acompanhamos a compra do imóvel do início à escritura."
	}
];
var planos = [
	{
		credito: "R$ 200 mil",
		parcela: "R$ 1.190",
		prazo: "200 meses"
	},
	{
		credito: "R$ 350 mil",
		parcela: "R$ 2.080",
		prazo: "200 meses",
		destaque: true
	},
	{
		credito: "R$ 500 mil",
		parcela: "R$ 2.970",
		prazo: "200 meses"
	}
];
var faq = [
	{
		q: "O que é consórcio imobiliário?",
		a: "É uma compra planejada e coletiva. Você entra em um grupo, paga parcelas mensais e é contemplado por sorteio ou lance com uma carta de crédito para comprar seu imóvel."
	},
	{
		q: "Preciso dar entrada?",
		a: "Não. Não existe entrada obrigatória — você começa pagando a primeira parcela do plano escolhido."
	},
	{
		q: "Posso usar o FGTS?",
		a: "Sim. O FGTS pode ser usado para dar lance, complementar a carta de crédito ou amortizar parcelas, conforme as regras vigentes."
	},
	{
		q: "Em quanto tempo sou contemplado?",
		a: "Depende do grupo e da estratégia de lance. Na consultoria montamos um plano realista para acelerar sua contemplação."
	}
];
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "liquid-page min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "glass-nav sticky top-0 z-50 border-b backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#topo",
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: grupo_invest_logo_default,
								alt: "Grupo Invest — Investimentos & Consórcios",
								className: "h-11 w-11 rounded-lg object-cover",
								width: 44,
								height: 44
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-sm font-semibold uppercase tracking-[0.2em] text-navy sm:block",
								children: "Grupo Invest"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "hidden items-center gap-7 text-sm font-medium text-muted-foreground md:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "transition-colors hover:text-navy",
									href: "#vantagens",
									children: "Vantagens"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "transition-colors hover:text-navy",
									href: "#como-funciona",
									children: "Como funciona"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "transition-colors hover:text-navy",
									href: "#simulador",
									children: "Simulador"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "transition-colors hover:text-navy",
									href: "#planos",
									children: "Planos"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "transition-colors hover:text-navy",
									href: "#gestores",
									children: "Gestores"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: WHATSAPP,
							className: "inline-flex items-center gap-2 rounded-full bg-navy px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.03]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), "Simular agora"]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "topo",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "liquid-hero relative overflow-hidden bg-brand-gradient",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:py-28 lg:grid-cols-[1.05fr_0.95fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "glass-card-dark inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), "Investimentos & Consórcios"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-6 text-4xl font-extrabold leading-[1.08] tracking-tight text-primary-foreground sm:text-5xl lg:text-6xl",
									children: ["Seu imóvel próprio", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sky",
										children: " sem juros e sem pressa."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 max-w-xl text-base leading-relaxed text-primary-foreground/80 sm:text-lg",
									children: "Crédito imobiliário e consórcio com curadoria do Grupo Invest. Planejamento honesto, estratégia de contemplação e acompanhamento até as chaves na mão."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-9 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: WHATSAPP,
										className: "inline-flex items-center gap-2 rounded-full bg-sky px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-soft transition-transform hover:scale-[1.03]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), "Falar com um gestor"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#simulador",
										className: "inline-flex items-center gap-2 rounded-full border border-primary-foreground/30 px-7 py-3.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-foreground/10",
										children: "Simular agora"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-primary-foreground/15 pt-7",
									children: [
										["+500", "famílias atendidas"],
										["0%", "de juros"],
										["100%", "acompanhamento"]
									].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-2xl font-extrabold text-sky sm:text-3xl",
										children: k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-xs uppercase tracking-wider text-primary-foreground/65",
										children: v
									})] }, v))
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "liquid-frame overflow-hidden rounded-[2rem] shadow-soft",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: hero_imovel_default,
										alt: "Prédio residencial moderno em dia ensolarado",
										width: 1280,
										height: 1280,
										className: "h-[380px] w-full object-cover sm:h-[460px]"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "glass-panel absolute -bottom-6 -left-4 flex items-center gap-3 rounded-2xl px-5 py-4 sm:left-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "h-9 w-9 text-sky" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-navy",
										children: "Carta de crédito"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Casa, apartamento, terreno ou reforma"
									})] })]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "vantagens",
						className: "mx-auto max-w-6xl px-5 py-20 md:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold uppercase tracking-[0.22em] text-sky",
									children: "Por que consórcio"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-bold tracking-tight text-navy sm:text-4xl",
									children: "A forma mais inteligente de comprar um imóvel"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-muted-foreground",
									children: "Enquanto o financiamento cobra juros por décadas, o consórcio transforma sua parcela em patrimônio."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
							children: beneficios.map(({ icon: Icon, titulo, texto }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "glass-card rounded-2xl p-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-flex h-12 w-12 items-center justify-center rounded-xl bg-sky-soft text-navy",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-5 text-lg font-bold text-navy",
										children: titulo
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: texto
									})
								]
							}, titulo))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "como-funciona",
						className: "bg-sky-soft/60 py-20 md:py-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "max-w-xl text-3xl font-bold tracking-tight text-navy sm:text-4xl",
								children: "Quatro passos até a sua carta de crédito"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4",
								children: passos.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "glass-card rounded-2xl p-7",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-3xl font-extrabold text-sky",
											children: p.n
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 text-lg font-bold text-navy",
											children: p.t
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-muted-foreground",
											children: p.d
										})
									]
								}, p.n))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "simulador",
						className: "bg-sky-soft/40 py-20 md:py-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold uppercase tracking-[0.22em] text-sky",
										children: "Simulador online"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 text-3xl font-bold tracking-tight text-navy sm:text-4xl",
										children: "Descubra sua parcela agora mesmo"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-muted-foreground",
										children: "Escolha a categoria, o valor do crédito e o prazo. O cálculo é instantâneo e sem compromisso."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimuladorConsorcio, { whatsapp: WHATSAPP })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "planos",
						className: "mx-auto max-w-6xl px-5 py-20 md:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold uppercase tracking-[0.22em] text-sky",
									children: "Simulações"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-bold tracking-tight text-navy sm:text-4xl",
									children: "Escolha o crédito e comece hoje"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-muted-foreground",
									children: "Valores de referência. A proposta exata é montada gratuitamente pelos nossos gestores."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-6 md:grid-cols-3",
							children: planos.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: p.destaque ? "rounded-3xl bg-brand-gradient p-8 shadow-soft" : "glass-card rounded-3xl p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: p.destaque ? "text-xs font-semibold uppercase tracking-[0.2em] text-sky" : "text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground",
										children: "Crédito"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: p.destaque ? "mt-2 text-3xl font-extrabold text-primary-foreground" : "mt-2 text-3xl font-extrabold text-navy",
										children: p.credito
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: p.destaque ? "mt-6 text-primary-foreground/80" : "mt-6 text-muted-foreground",
										children: [
											"a partir de",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: p.destaque ? "text-sky" : "text-navy",
												children: p.parcela
											}),
											" /mês"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: p.destaque ? "mt-1 text-sm text-primary-foreground/65" : "mt-1 text-sm text-muted-foreground",
										children: ["em até ", p.prazo]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-6 space-y-2",
										children: [
											"Sem juros",
											"Sem entrada",
											"Uso do FGTS permitido"
										].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: p.destaque ? "flex items-center gap-2 text-sm text-primary-foreground/85" : "flex items-center gap-2 text-sm text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-sky" }), i]
										}, i))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: WHATSAPP,
										className: p.destaque ? "mt-8 inline-flex w-full items-center justify-center rounded-full bg-sky px-6 py-3 text-sm font-bold text-primary-foreground" : "mt-8 inline-flex w-full items-center justify-center rounded-full bg-navy px-6 py-3 text-sm font-bold text-primary-foreground",
										children: "Quero simular"
									})
								]
							}, p.credito))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "gestores",
						className: "liquid-dark-section bg-navy-deep py-20 md:py-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl items-center gap-12 px-5 lg:grid-cols-[1fr_1fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: gestores_default,
									alt: "Luiz Ricardo e Talia Pinheiro, gestores do Grupo Invest",
									loading: "lazy",
									width: 638,
									height: 638,
									className: "w-full rounded-[2rem] object-cover shadow-soft"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "glass-panel absolute -bottom-6 left-6 right-6 rounded-2xl px-5 py-4 sm:right-auto",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-navy",
										children: "Luiz Ricardo & Talia Pinheiro"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Gestores do Grupo Invest"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold uppercase tracking-[0.22em] text-sky",
									children: "Quem conduz o seu plano"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl",
									children: "Uma gestão feita a quatro mãos"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 leading-relaxed text-primary-foreground/75",
									children: "O Grupo Invest é conduzido por Luiz Ricardo e Talia Pinheiro. Juntos, eles unem estratégia financeira e atendimento próximo para que cada cliente saia do aluguel com clareza — sem promessas irreais e sem letras miúdas."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-9 grid gap-4 sm:grid-cols-2",
									children: [{
										nome: "Luiz Ricardo",
										cargo: "Gestor de Crédito & Estratégia",
										bio: "Estrutura cartas de crédito, estratégias de lance e a melhor rota até a contemplação."
									}, {
										nome: "Talia Pinheiro",
										cargo: "Gestora de Relacionamento",
										bio: "Acompanha cada cliente do primeiro cálculo à escritura, com transparência total."
									}].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "glass-card-dark rounded-2xl p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "inline-flex h-11 w-11 items-center justify-center rounded-xl bg-sky/20 text-sky",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "h-5 w-5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-4 text-lg font-bold text-primary-foreground",
												children: g.nome
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold uppercase tracking-wider text-sky",
												children: g.cargo
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-sm leading-relaxed text-primary-foreground/70",
												children: g.bio
											})
										]
									}, g.nome))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-8 grid gap-3 sm:grid-cols-2",
									children: [
										"Atendimento 100% personalizado",
										"Estratégia de lance sob medida",
										"Transparência em cada taxa",
										"Suporte após a contemplação"
									].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-2 text-sm text-primary-foreground/85",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0 text-sky" }), i]
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: WHATSAPP,
									className: "mt-9 inline-flex items-center gap-2 rounded-full bg-sky px-7 py-3.5 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.03]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }), "Falar com os gestores"]
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto max-w-4xl px-5 py-20 md:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-bold tracking-tight text-navy sm:text-4xl",
							children: "Dúvidas frequentes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "glass-panel mt-10 divide-y divide-border rounded-3xl px-6",
							children: faq.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "group py-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
									className: "flex cursor-pointer list-none items-center justify-between gap-4 text-base font-semibold text-navy",
									children: [f.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sky transition-transform group-open:rotate-45",
										children: "+"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: f.a
								})]
							}, f.q))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mx-auto max-w-6xl px-5 pb-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "liquid-cta overflow-hidden rounded-[2rem] bg-brand-gradient px-8 py-14 text-center shadow-soft sm:px-16",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl font-extrabold tracking-tight text-primary-foreground sm:text-4xl",
									children: "O próximo endereço da sua família começa aqui"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-4 max-w-xl text-primary-foreground/80",
									children: "Simulação gratuita e sem compromisso. Responda algumas perguntas e receba seu plano ideal hoje mesmo."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: WHATSAPP,
									className: "mt-8 inline-flex items-center gap-2 rounded-full bg-sky px-8 py-4 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.03]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), "Quero minha simulação"]
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "glass-nav border-t py-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col items-center gap-4 px-5 text-center sm:flex-row sm:justify-between sm:text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: grupo_invest_logo_default,
							alt: "Grupo Invest",
							loading: "lazy",
							width: 40,
							height: 40,
							className: "h-10 w-10 rounded-lg object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-semibold text-navy",
							children: ["Grupo Invest", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-normal text-muted-foreground",
								children: "Investimentos & Consórcios"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"© ",
							(/* @__PURE__ */ new Date()).getFullYear(),
							" Grupo Invest. Consórcio não é financiamento — administradoras autorizadas pelo Banco Central."
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { Index as component };
