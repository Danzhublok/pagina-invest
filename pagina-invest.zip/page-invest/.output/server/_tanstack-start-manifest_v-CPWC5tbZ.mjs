//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CPWC5tbZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/projetos/page-invest/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BOFaiWvK.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BOFaiWvK.js"
		} }]
	},
	"/": {
		filePath: "D:/projetos/page-invest/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D_tE1ufc.js"]
	}
} });
//#endregion
export { tsrStartManifest };
